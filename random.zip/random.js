let numb = (Math.floor(Math.random()*1000));

let hundrets = (Math.floor(numb / 100));

let tens = (Math.floor(numb % 100 / 10));

let units = (numb % 10);

if (hundrets == 9) {
    console.log(`ДевятСот`)
}
if (hundrets == 8) {
    console.log(`Восемсот`)
}
if (hundrets == 7) {
    console.log(`Семсот`)
}
if (hundrets == 6) {
    console.log(`ШЫшсот`)
}
if (hundrets == 5) {
    console.log(`Пяттсот`)
}
if (hundrets == 4) {
    console.log(`Четыреста`)
}
if (hundrets == 3) {
    console.log(`Триста`)
}
if (hundrets == 2) {
    console.log(`Двести`)
}
if (hundrets == 1) {
    console.log(`Сто`)
}


if (tens == 9) {
    console.log(`девеносто`)
}
if (tens == 8) {
    console.log(`восемдесят`)
}
if (tens == 7) {
    console.log(`семдэсат`)
}
if (tens == 6) {
    console.log(`шышдесят`)
}
if (tens == 5) {
    console.log(`пядисят`)
}
if (tens == 4) {
    console.log(`сороК`)
}
if (tens == 3) {
    console.log(`тредцать`)
}
if (tens == 2) {
    console.log(`двадцать`)
}
if (tens == 0) {
    console.log(``)
}

// мне помогав Антон

if (tens == 1) {
    if (units == 9) {
        console.log(`девятнадцат`)
    }
    if (units == 8) {
        console.log(`весемнадцат`)
    }
    if (units == 7) {
        console.log(`семнадцат`)
    }
    if (units == 6) {
        console.log(`ШЫШнадцат`)
    }
    if (units == 5) {
        console.log(`пятнадцат`)
    }
    if (units == 4) {
        console.log(`четырнадцат`)
    }
    if (units == 3) {
        console.log(`тринадцат`)
    }
    if (units == 2) {
        console.log(`двинадцат`)
    }
    if (units == 1) {
        console.log(`одЫнадцат`)
    }
    if (tens == 0) {
        console.log(`дэсат`)
    }
    
}

if (tens !== 1){

// ошыбочка в коде ЫЫЫ!

if (units == 9) {
    console.log(`девят`)
}
if (units == 8) {
    console.log(`восеМ`)
}
if (units == 7) {
    console.log(`сем`)
}
if (units == 6) {
    console.log(`шест`)
}
if (units == 5) {
    console.log(`пят`)
}
if (units == 4) {
    console.log(`четыре`)
}
if (units == 3) {
    console.log(`три`)
}
if (units == 2) {
    console.log(`два`)
}
if (units == 1) {
    console.log(`одын`)
}

}


